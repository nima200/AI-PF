﻿public abstract class LeafNode : BehaviorNode {

}
