﻿public enum BehaviorResult
{
    Failure,
    Success,
    Running
}